package eleven_inheritance;

public class ContentReviewer extends Guest {
    public static void main(String[] args) {
        watchVideo();
    }
}
