package eleven_inheritance;

public class Guest {

    // watch video - 500 line of code
    public static void watchVideo() {
        System.out.println("W");
        System.out.println("A");
        System.out.println("T");
        System.out.println("C");
        System.out.println("H");
        System.out.println(".");
        System.out.println(".");
        System.out.println(".");
        System.out.println(".");
        System.out.println(".");
        System.out.println(".");
        System.out.println(".");
        System.out.println(".");
        System.out.println(".");
        System.out.println("V");
        System.out.println("I");
        System.out.println("D");
        System.out.println("E");
        System.out.println("O");
    }

    public static void main(String[] args) {
        watchVideo();
    }

}
