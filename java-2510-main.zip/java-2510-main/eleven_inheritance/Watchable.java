package eleven_inheritance;

public interface Watchable {

    // concrete method
    // public void watchVideo() {
    //     System.out.println("W");
    //     System.out.println("A");
    //     System.out.println("T");
    //     System.out.println("C");
    //     System.out.println("H");
    //     System.out.println(".");
    //     System.out.println(".");
    //     System.out.println(".");
    //     System.out.println(".");
    //     System.out.println(".");
    //     System.out.println(".");
    //     System.out.println(".");
    //     System.out.println(".");
    //     System.out.println(".");
    //     System.out.println("V");
    //     System.out.println("I");
    //     System.out.println("D");
    //     System.out.println("E");
    //     System.out.println("O");
    // }

    // abstract methods -> no implementation i.e no body
    public void watchVideo();

}
