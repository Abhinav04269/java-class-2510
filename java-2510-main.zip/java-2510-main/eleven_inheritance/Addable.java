package eleven_inheritance;

public interface Addable {

    // abstract methods -> no implementation i.e no body
    public void addVideo();

}
