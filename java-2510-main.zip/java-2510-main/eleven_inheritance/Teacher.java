package eleven_inheritance;

public class Teacher extends Guest {
    public static void main(String[] args) {
        watchVideo();
    }
}
