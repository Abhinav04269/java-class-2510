class App {
    // if you want to run a java program, class and main method 
    // are must
    // public - access modifier
    // static - no object is required to run program
    // void - retrun nothing
    // main - method name, String[] args
    public static void main(String[] args) {
        // method body
        System.out.println("Hello World V3");
    }
}
